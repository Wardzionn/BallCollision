using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ModelTest
{
    [TestClass]
    public class ModelTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}