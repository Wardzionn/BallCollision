﻿using Data;
using Logic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Numerics;

namespace LogicTest
{
    [TestClass]
    public class CanvasTest
    {
        [TestMethod]
        public void TestMethod1()
        {
 



        }
    }
}